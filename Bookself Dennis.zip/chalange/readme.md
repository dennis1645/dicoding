# SMKDEV Coding Challenge Submission #7644

## Tanda Pengenal :

- Nama : Dennis Satriani Sucipto Putra
- Status : Mahasiswa
- Instansi : Universitas Catur Insan Cendikia
- LinkedIn : https://www.linkedin.com/in/dennis-satriani-sucipto-putra-678815288/
- Web Portofolio : https://react-portofolio-dennis.netlify.app/
- Slogan : "virtualis mundi, victores sumus" yang artisnya di dunia maya, kita berjaya.

## DATA SET

- underscore_case
- first_name
- Some_Variable
- calculate_AGE
- delayed_departure

## Penjelasan Algoritma :

1. Input dari text area akan di ubah kedalam bentuk array.dengan memisahkan spasi '\n' sebagai parameter fungsi split.
2. Input yang berbentuk array kemudian kita deklarasikan menggunakan destructuring assignment di dalam JavaScript. Dalam kasus ini, inputArray adalah sebuah array yang berisi beberapa elemen, dan pernyataan tersebut membagi elemen-elemen tersebut ke dalam variabel-variabel terpisah word1, word2, word3, word4, dan word5 berdasarkan urutan mereka dalam array.
3. Kemudian setelah selesai kita lakukan perulangan untuk memisahkan nya dari '\_' kemudian membuat urutan array 1 dari variabel tersebut menjadi huruf kapital di awal. setelah itu di push ke dalam array kosong bernama camel.
4. cetak camel melalui perulangan, dan selesai.

## Terima Kasih
